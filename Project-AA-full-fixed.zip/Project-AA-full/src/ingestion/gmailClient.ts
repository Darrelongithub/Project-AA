/**
 * /ingestion — live Gmail access via the Gmail API (googleapis).
 *
 * Auth: OAuth2 "installed app" style — client id/secret + a refresh token
 * for the test inbox. Only what the pipeline needs is implemented:
 *   - list recent message ids (a configurable label, paginated)
 *   - fetch one message with attachments (inline documents included)
 *   - send a plain-text reply inside a thread
 *
 * Round 19 hardening:
 *   - the mailbox is paginated — more than the first 50 messages are seen;
 *   - a dedicated label can be watched instead of (or as well as) the inbox;
 *   - inline images that ARE the document are captured as attachments;
 *   - a size guard rejects oversized mail BEFORE base64-buffering it.
 */
import type { IncomingEmail } from "../types";
import { envInt } from "../util/envnum";
import { MAX_ATTACHMENT_BYTES } from "../extraction/extract";
import { log, logField } from "../util/log";

/** Whole-message cap; above this the mail is parked, never downloaded. */
export const MAX_EMAIL_BYTES = envInt(process.env.GMAIL_MAX_EMAIL_BYTES, 40 * 1024 * 1024);

/** A message too big to process — park it permanently, tell a human. */
export class EmailTooLargeError extends Error {
  sizeEstimate: number;
  constructor(messageId: string, sizeEstimate: number) {
    super(
      `message ${messageId} is ~${(sizeEstimate / 1024 / 1024).toFixed(1)} MB — above the ${(MAX_EMAIL_BYTES / 1024 / 1024).toFixed(0)} MB mail cap`
    );
    this.sizeEstimate = sizeEstimate;
    this.name = "EmailTooLargeError";
  }
}

/**
 * Header-safe `To`/`Subject` values for raw MIME construction. CR/LF in a
 * staff-editable subject would otherwise inject arbitrary headers (Cc/Bcc…);
 * non-ASCII subjects must be RFC 2047 encoded or the headers are invalid.
 */
export function sanitizeHeaders(to: string, subject: string): { to: string; subject: string } {
  const cleanTo = to.replace(/[\r\n]+/g, " ").trim();
  let cleanSubject = subject.replace(/[\r\n]+/g, " ").trim();
  if (/[^\x20-\x7e]/.test(cleanSubject)) {
    cleanSubject = `=?UTF-8?B?${Buffer.from(cleanSubject, "utf8").toString("base64")}?=`;
  }
  return { to: cleanTo, subject: cleanSubject };
}

interface MimePartNode {
  mimeType: string;
  headers?: Array<{ name: string; value: string }>;
  filename?: string;
  body?: { data?: string; attachmentId?: string; size?: number };
  parts?: MimePartNode[];
}

export class GmailClient {
  private gmail: any;
  readonly address: string;

  readonly label?: string;

  constructor(cfg: {
    address: string;
    clientId: string;
    clientSecret: string;
    refreshToken: string;
    /** Gmail label to watch (default: the inbox). */
    label?: string;
    /**
     * Override the Gmail API root URL. Real uses: a corporate proxy or a
     * sandbox that speaks the same wire format — including the tests, which
     * run the actual client (MIME building, base64url, thread retry, MIME
     * parsing) against a local server instead of a hand-written stub.
     */
    apiUrl?: string;
    /**
     * A live access token. When present and unexpired, no round-trip to
     * Google's token endpoint is made — which is what lets a sandbox (or a
     * deployment that manages its own tokens) work without the refresh hop.
     */
    accessToken?: string;
    accessTokenExpiry?: number;
  }) {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const { google } = require("googleapis");
    const oauth2 = new google.auth.OAuth2(cfg.clientId, cfg.clientSecret);
    oauth2.setCredentials({
      refresh_token: cfg.refreshToken,
      ...(cfg.accessToken
        ? { access_token: cfg.accessToken, expiry_date: cfg.accessTokenExpiry ?? Date.now() + 3600_000 }
        : {}),
    });
    // `rootUrl` is the googleapis override for the API root: every request path
    // is resolved against it (new URL(path, rootUrl)), so it must end in "/".
    const rootUrl = cfg.apiUrl ? (cfg.apiUrl.endsWith("/") ? cfg.apiUrl : `${cfg.apiUrl}/`) : undefined;
    this.gmail = google.gmail({ version: "v1", auth: oauth2, ...(rootUrl ? { rootUrl } : {}) });
    this.address = cfg.address;
    this.label = cfg.label?.trim() || undefined;
  }

  /** Which mailbox region we read from — shown on the Configuration page. */
  watchTarget(): string {
    return this.label ? `label:${this.label}` : "all mail (excluding sent, spam and trash)";
  }

  async listRecentMessageIds(
    lookbackDays: number,
    opts: { perPage?: number; maxPages?: number } = {}
  ): Promise<string[]> {
    const perPage = Math.min(opts.perPage ?? 100, 500);
    const maxPages = opts.maxPages ?? 10;
    // `in:inbox` misses archived mail — a common reason an applicant appears
    // in Gmail but never reaches the console. Read the mailbox-wide region by
    // default, while excluding messages the intake app should never
    // triage: sent mail, spam and trash. A configured label remains an
    // intentional narrower watch target.
    const scope = this.label ? `label:${this.label}` : "in:anywhere -in:spam -in:trash -from:me";
    const q = `${scope} newer_than:${lookbackDays}d`;

    const ids: string[] = [];
    let pageToken: string | undefined;
    for (let page = 0; page < maxPages; page++) {
      const res = await this.gmail.users.messages.list({
        userId: "me",
        q,
        maxResults: perPage,
        ...(pageToken ? { pageToken } : {}),
      });
      for (const m of (res.data.messages || []) as Array<{ id: string }>) ids.push(m.id);
      pageToken = res.data.nextPageToken || undefined;
      if (!pageToken) break;
    }
    return ids;
  }

  async fetchEmail(id: string): Promise<IncomingEmail> {
    // Size guard BEFORE downloading: a 40 MB scan used to be base64-buffered
    // into memory before anything noticed. Metadata is tiny and carries the
    // server's own size estimate.
    const meta = await this.gmail.users.messages.get({ userId: "me", id, format: "metadata" });
    const sizeEstimate = Number(meta.data.sizeEstimate || 0);
    if (sizeEstimate > MAX_EMAIL_BYTES) throw new EmailTooLargeError(id, sizeEstimate);

    const res = await this.gmail.users.messages.get({ userId: "me", id, format: "full" });
    const msg = res.data;
    const headers: Record<string, string> = {};
    for (const h of msg.payload.headers || []) headers[h.name.toLowerCase()] = h.value;

    const fromHeader = headers["from"] || "";
    const fromMatch = fromHeader.match(/<([^<>]+)>/) || fromHeader.match(/([^\s<>]+@[^\s<>]+)/);
    const from = fromMatch ? fromMatch[1] : fromHeader;
    const nameMatch = fromHeader.match(/^"?\s*([^"<]+?)\s*"?\s*</);

    const bodyParts: string[] = [];
    const attachments: Array<{
      filename: string;
      mimeType: string;
      attachmentId?: string;
      /** Some clients embed inline images as base64 directly in the part. */
      data?: Buffer;
      size?: number;
    }> = [];

    const walk = (part: MimePartNode) => {
      const disposition = (part.headers || []).find((h) => h.name.toLowerCase() === "content-disposition")?.value || "";
      const isDocumentish =
        /^(application\/pdf|image\/(png|jpe?g|tiff?|webp|heic|heif))$/i.test(part.mimeType) ||
        /\.(pdf|png|jpe?g|tiff?|webp|heic|heif)$/i.test(part.filename || "");
      if (part.body?.attachmentId) {
        // Named attachments always; INLINE images of document types too —
        // phone users paste their scan into the message body itself.
        const inlineDocument = /inline/i.test(disposition) && isDocumentish;
        if ((part.filename && part.filename.length > 0) || inlineDocument) {
          let filename = part.filename && part.filename.length > 0 ? part.filename : "";
          if (!filename) {
            const cid = (part.headers || []).find((h) => h.name.toLowerCase() === "content-id")?.value || "";
            filename = `inline-${cid.replace(/[<>]/g, "") || attachments.length + 1}.${part.mimeType.split("/")[1] || "bin"}`;
          }
          attachments.push({ filename, mimeType: part.mimeType, attachmentId: part.body.attachmentId, size: part.body.size });
          return;
        }
      } else if (/inline/i.test(disposition) && isDocumentish && part.body?.data) {
        // Inline document image carried directly in the part (no attachmentId).
        const cid = (part.headers || []).find((h) => h.name.toLowerCase() === "content-id")?.value || "";
        const ext = part.mimeType.split("/")[1] || "bin";
        const filename =
          part.filename && part.filename.length > 0
            ? part.filename
            : `inline-${cid.replace(/[<>]/g, "") || attachments.length + 1}.${ext}`;
        attachments.push({
          filename,
          mimeType: part.mimeType,
          data: Buffer.from(part.body.data, "base64"),
          size: part.body.size,
        });
        return;
      }
      if (part.mimeType === "text/plain" && part.body?.data) {
        bodyParts.push(Buffer.from(part.body.data, "base64").toString("utf8"));
      }
      for (const child of part.parts || []) walk(child);
    };
    walk(msg.payload);

    // If there was no text/plain part, degrade to stripped HTML.
    let body = bodyParts.join("\n");
    if (!body.trim()) {
      const htmlParts: string[] = [];
      const walkHtml = (part: MimePartNode) => {
        if (part.mimeType === "text/html" && part.body?.data) {
          htmlParts.push(Buffer.from(part.body.data, "base64").toString("utf8"));
        }
        for (const child of part.parts || []) walkHtml(child);
      };
      walkHtml(msg.payload);
      body = htmlParts.join("\n").replace(/<[^>]+>/g, " ").replace(/\s+/g, " ");
    }

    const attachmentBuffers = await Promise.all(
      attachments
        .filter((a) => {
          // The extraction layer enforces the same cap on bytes, but an
          // attachment that DECLARES itself oversized is never downloaded.
          const declared = a.size ?? a.data?.length ?? 0;
          if (declared > MAX_ATTACHMENT_BYTES) {
            log(`gmail: skipping ${logField(a.filename)} — declared ${(declared / 1024 / 1024).toFixed(1)} MB exceeds the ${MAX_ATTACHMENT_BYTES / 1024 / 1024} MB attachment cap`, "warn");
            return false;
          }
          return true;
        })
        .map(async (a) => {
          if (a.data) {
            // Inline image already carried its bytes in the MIME part.
            return { filename: a.filename, mimeType: a.mimeType, content: a.data };
          }
          const attRes = await this.gmail.users.messages.attachments.get({
            userId: "me",
            messageId: id,
            id: a.attachmentId!,
          });
          return {
            filename: a.filename,
            mimeType: a.mimeType,
            content: Buffer.from(attRes.data.data, "base64"),
          };
        })
    );

    return {
      id,
      threadId: msg.threadId,
      from,
      fromName: nameMatch ? nameMatch[1].trim() : undefined,
      // Which of our mailboxes received it — the tenant attribution signal.
      // Delivered-To is the envelope recipient when the provider supplies it;
      // To (and Cc) cover aliases and shared mailboxes.
      to: [headers["delivered-to"], headers["to"], headers["cc"]].filter(Boolean).join(", "),
      subject: headers["subject"] || "(no subject)",
      body,
      // Some messages (drafts, imported mail) carry no internalDate — a NaN
      // date used to throw toISOString() and silently drop the message.
      receivedAt: msg.internalDate
        ? new Date(Number(msg.internalDate)).toISOString()
        : new Date().toISOString(),
      attachments: attachmentBuffers,
    };
  }

  async sendReply(
    to: string,
    subject: string,
    body: string,
    threadId: string,
    extras?: { attachments?: Array<{ filename: string; mimeType: string; content: Buffer }>; banner?: { mime: string; base64: string } | null; fromName?: string | null; fromAddress?: string | null; replyTo?: string | null; signatureHtml?: string; signatureText?: string }
  ): Promise<void> {
    const { to: cleanTo, subject: cleanSubject } = sanitizeHeaders(to, subject);
    const headers = [`To: ${cleanTo}`, `Subject: ${cleanSubject}`, "MIME-Version: 1.0"];
    // PPR P1-5: organization sender identity actually shapes the MIME. The
    // display name and reply-to are sanitized like any other header value.
    const headerSafe = (v: string) => v.replace(/[\r\n]+/g, " ").replace(/[<>]/g, "").trim();
    const fromName = (extras?.fromName ?? "").trim() ? headerSafe(String(extras?.fromName)) : "";
    const fromAddress = (extras?.fromAddress ?? "").trim() ? headerSafe(String(extras?.fromAddress)) : "";
    if (fromName || fromAddress) {
      headers.push(fromName ? `From: "${fromName.replace(/"/g, "")}" <${fromAddress || this.address}>` : `From: ${fromAddress}`);
    }
    const replyTo = (extras?.replyTo ?? "").trim() ? headerSafe(String(extras?.replyTo)) : "";
    if (replyTo) headers.push(`Reply-To: ${replyTo}`);

    const b64 = (buf: Buffer | string) => {
      const s = typeof buf === "string" ? buf : buf.toString("base64");
      return s.match(/.{1,76}/g)?.join("\r\n") ?? "";
    };
    const attachments = extras?.attachments ?? [];
    const banner = extras?.banner ?? null;

    let raw: string;
    if (!banner && attachments.length === 0) {
      raw = [...headers, "Content-Type: text/plain; charset=UTF-8", "", body].join("\r\n");
    } else {
      // multipart/mixed [ related(text + inline banner), att, att, … ]
      const mixed = "RU-MIXED-" + Date.now().toString(16);
      const related = "RU-REL-" + Date.now().toString(16);
      const parts: string[] = [];
      if (banner) {
        // Embed banner via CID in HTML so clients show a header, not a loose image attachment.
        const escapedBody = body
          .replace(/&/g, "&amp;")
          .replace(/</g, "&lt;")
          .replace(/>/g, "&gt;");
        const htmlBody =
          `<!DOCTYPE html><html><body style="margin:0;padding:0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;color:#1f1729;">` +
          `<div style="max-width:640px;margin:0 auto;">` +
          `<img src="cid:organization-banner" alt="" style="display:block;width:100%;max-width:720px;height:auto;border:0;" />` +
          `<div style="padding:20px 8px 8px;white-space:pre-wrap;font-size:15px;line-height:1.55;">${escapedBody}</div>` +
          (extras?.signatureHtml || "") +
          `</div></body></html>`;
        const alt = "ALT-" + Date.now().toString(16);
        parts.push(
          [
            `--${mixed}`,
            `Content-Type: multipart/related; boundary="${related}"`,
            "",
            `--${related}`,
            `Content-Type: multipart/alternative; boundary="${alt}"`,
            "",
            `--${alt}`,
            "Content-Type: text/plain; charset=UTF-8",
            "",
            body + (extras?.signatureText && !body.includes("\n--\n") ? extras.signatureText : ""),
            "",
            `--${alt}`,
            "Content-Type: text/html; charset=UTF-8",
            "",
            htmlBody,
            `--${alt}--`,
            "",
            `--${related}`,
            `Content-Type: ${banner.mime}; name="organization-banner"`,
            `Content-Disposition: inline; filename="organization-banner"`,
            "Content-Transfer-Encoding: base64",
            "Content-Id: <organization-banner>",
            "",
            b64(banner.base64),
            `--${related}--`,
          ].join("\r\n")
        );
      } else {
        parts.push([`--${mixed}`, "Content-Type: text/plain; charset=UTF-8", "", body].join("\r\n"));
      }
      for (const a of attachments) {
        const safeName = a.filename.replace(/[^\x20-\x7e]/g, "_").replace(/"/g, "'");
        parts.push(
          [
            `--${mixed}`,
            `Content-Type: ${a.mimeType}; name="${safeName}"`,
            `Content-Disposition: attachment; filename="${safeName}"`,
            "Content-Transfer-Encoding: base64",
            "",
            b64(a.content),
          ].join("\r\n")
        );
      }
      raw = [...headers, `Content-Type: multipart/mixed; boundary="${mixed}"`, "", parts.join("\r\n"), `--${mixed}--`, ""].join("\r\n");
    }

    const encoded = Buffer.from(raw, "utf8")
      .toString("base64")
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/, "");
    try {
      await this.gmail.users.messages.send({
        userId: "me",
        requestBody: { raw: encoded, threadId },
      });
    } catch (e) {
      const apiError = e as { errors?: Array<{ reason?: string; message?: string }>; message?: string };
      // Gmail reports a bad thread as reason "notFound" (no space) with a
      // human message alongside it. Matching only the message meant the retry
      // below never fired in production: a deleted or moved conversation made
      // the reply fail outright instead of going out as a new message.
      const reason = [apiError?.errors?.[0]?.reason, apiError?.errors?.[0]?.message, apiError?.message].filter(Boolean).join(" ");
      // A stale/unknown thread id (conversation deleted, case created outside
      // Gmail) must not kill the send. Retry as a fresh message — the contact
      // still gets the reply, just as a new thread.
      if (/thread|not ?found|invalid/i.test(reason)) {
        await this.gmail.users.messages.send({ userId: "me", requestBody: { raw: encoded } });
        return;
      }
      throw e;
    }
  }
}
