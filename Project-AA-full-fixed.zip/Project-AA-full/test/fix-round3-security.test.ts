/**
 * Round-3 security fixes — verified bugs from the master-checklist audit:
 *
 *  B1  /case/:id middleware must reject cross-realm access (live ↔ demo) for
 *      EVERY route under it, not just the two GETs that re-check manually.
 *  B2  All three CSV exports must filter realm + school scope.
 *  B3  Retention archives are encrypted and stored with private permissions.
 *  B4  Login-failure map prunes by time, never a blunt clear at 5,000.
 *  B5  Retention defaults to the LIVE realm only (explicit flag to widen).
 *  B6  Admin password reset gets the same rules as first-run setup
 *      (≥8 chars + confirm match).
 */
import { afterEach, beforeEach, describe, expect, it } from "vitest";
import * as fs from "fs";
import * as os from "os";
import * as path from "path";
import { spawnSync } from "node:child_process";
import { Repo } from "../src/db/repo";
import { openDb } from "../src/db/db";
import { seedDefaults } from "../src/db/seed";
import { createApp } from "../src/web/server";
import { hashPassword, verifyPassword } from "../src/util/password";
import { decryptArchive, parseArchiveEncryptionKey } from "../src/util/archiveCrypto";
import { webLogin, configureTestOrganization } from "./helpers";
import type { PipelineContext } from "../src/pipeline/adapters";
import type { Server } from "http";

let repo: Repo;
let server: Server | undefined;

beforeEach(() => {
  repo = new Repo(openDb(":memory:"));
  seedDefaults(repo);
  configureTestOrganization(repo);
});
afterEach(() => { server?.close(); server = undefined; });

async function boot(extraStaff: Array<{ u: string; p: string; demo?: boolean }> = []): Promise<string> {
  repo.createStaff("admin", "Live Admin", hashPassword("admin123"), "admin");
  for (const s of extraStaff) repo.createStaff(s.u, s.u, hashPassword(s.p), "admin", s.demo ?? false);
  const ctx: PipelineContext = { repo, adapters: { vision: null as never, watcher: null as never, sender: null as never } };
  const s = createApp({ repo, ctx }).listen(0);
  server = s;
  return `http://127.0.0.1:${(s.address() as { port: number }).port}`;
}

function mkApplicant(ref: string, demo: 0 | 1): number {
  const a = repo.getOrCreateApplicant(`${ref}@example.ke`, `thr-${ref}`);
  (repo as unknown as { db: { prepare: (q: string) => { run: (...x: unknown[]) => unknown } } }).db
    .prepare("UPDATE applicants SET demo = ? WHERE id = ?").run(demo, a.id);
  return a.id;
}

describe("B1 — one realm guard at the /case/:id choke point", () => {
  it("cross-realm POST mutations return 404 (both directions), same-realm still works", async () => {
    const base = await boot([{ u: "demo", p: "demo12345", demo: true }]);
    const liveId = mkApplicant("live-case", 0);
    const demoId = mkApplicant("demo-case", 1);

    const { cookie: liveCk, csrf: liveCs } = await webLogin(base, "admin", "admin123");
    const { cookie: demoCk, csrf: demoCs } = await webLogin(base, "demo", "demo12345");

    const note = (id: number, cookie: string, csrf: string) =>
      fetch(`${base}/case/${id}/note`, {
        method: "POST", redirect: "manual",
        headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
        body: `_csrf=${encodeURIComponent(csrf)}&note=hello`,
      });
    // demo admin MUST NOT be able to mutate the live case (today: 302 — the bug)
    expect((await note(liveId, demoCk, demoCs)).status).toBe(404);
    // live admin MUST NOT be able to mutate the demo case either
    expect((await note(demoId, liveCk, liveCs)).status).toBe(404);
    // and a second mutation route, to prove the guard is the middleware, not luck
    const task = (id: number, cookie: string, csrf: string) =>
      fetch(`${base}/case/${id}/task/add`, {
        method: "POST", redirect: "manual",
        headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
        body: `_csrf=${encodeURIComponent(csrf)}&title=t&due=2026-10-01`,
      });
    expect((await task(liveId, demoCk, demoCs)).status).toBe(404);
    // same-realm still flows through
    expect((await note(liveId, liveCk, liveCs)).status).toBe(302);
    expect((await note(demoId, demoCk, demoCs)).status).toBe(302);
    // cross-realm reads were already 404; keep them pinned
    const read = await fetch(`${base}/case/${liveId}`, { headers: { cookie: demoCk } });
    expect(read.status).toBe(404);
  });
});

describe("B2 — CSV exports honour realm + school scope", () => {
  it("applicants.csv, queue.csv and audit.csv contain only the caller's realm", async () => {
    const base = await boot([{ u: "demo", p: "demo12345", demo: true }]);
    const liveId = mkApplicant("exp-live", 0);
    const demoId = mkApplicant("exp-demo", 1);
    (repo as unknown as { db: { prepare: (q: string) => { run: (...x: unknown[]) => unknown } } }).db
      .prepare("UPDATE applicants SET lifecycle = 'awaiting_review' WHERE id IN (?, ?)").run(liveId, demoId);
    repo.audit(liveId, "admin", "test_event", "live-detail");
    repo.audit(demoId, "demo", "test_event", "demo-detail");
    repo.audit(null, "admin", "system_event", "no applicant attached");

    const { cookie } = await webLogin(base, "admin", "admin123");
    const csv = async (p: string) => (await fetch(`${base}${p}`, { headers: { cookie } })).text();

    const apps = await csv("/export/applicants.csv");
    expect(apps).toContain("exp-live@example.ke");
    expect(apps).not.toContain("exp-demo@example.ke");
    const queue = await csv("/export/queue.csv");
    expect(queue).not.toContain("exp-demo@example.ke");
    const audit = await csv("/export/audit.csv");
    expect(audit).toContain("live-detail");
    expect(audit).toContain("system_event"); // unattached rows survive
    expect(audit).not.toContain("demo-detail");
  });
});

describe("B3+B5 — retention: archive dir locked, live realm by default", () => {
  it("archives old completed LIVE cases only; demo untouched; dir mode 0700", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "retain-"));
    const dbPath = path.join(dir, "t.sqlite");
    const r = new Repo(openDb(dbPath));
    seedDefaults(r);
    configureTestOrganization(r);
    const raw = r as unknown as { db: { prepare: (q: string) => { run: (...x: unknown[]) => unknown; get: (...x: unknown[]) => { n: number } } } };
    const old = new Date(Date.now() - 1000 * 24 * 3600_000).toISOString();
    const live = r.getOrCreateApplicant("old-live@example.ke", "t1");
    raw.db.prepare("UPDATE applicants SET lifecycle='completed', demo=0, updated_at=? WHERE id=?").run(old, live.id);
    const demo = r.getOrCreateApplicant("old-demo@example.ke", "t2");
    raw.db.prepare("UPDATE applicants SET lifecycle='completed', demo=1, updated_at=? WHERE id=?").run(old, demo.id);

    const archiveKey = "4b".repeat(32);
    const run = spawnSync("./node_modules/.bin/tsx", ["src/cli/retain.ts"], {
      cwd: path.resolve(__dirname, ".."),
      env: { ...process.env, DB_PATH: dbPath, DISABLE_OCR: "1", ARCHIVE_ENCRYPTION_KEY: archiveKey },
      timeout: 60_000,
    });
    expect(run.status).toBe(0);

    const r2 = new Repo(openDb(dbPath));
    expect(r2.getApplicant(live.id)).toBeUndefined();       // archived + removed
    expect(r2.getApplicant(demo.id)).toBeDefined();          // demo NOT swept
    const archiveDir = path.join(dir, "archive");
    const mode = fs.statSync(archiveDir).mode & 0o777;
    expect(mode).toBe(0o700);                                 // dir locked (today: 0755)
    const file = fs.readdirSync(archiveDir)[0];
    expect(file).toBe(`${live.ref_number}.json.enc`);
    const encrypted = fs.readFileSync(path.join(archiveDir, file), "utf8");
    expect(encrypted).not.toContain("old-live@example.ke");
    const archive = JSON.parse(decryptArchive(encrypted, parseArchiveEncryptionKey(archiveKey))) as {
      applicant: { id: number; email_address: string };
    };
    expect(archive.applicant.id).toBe(live.id);
    expect(archive.applicant.email_address).toBe("old-live@example.ke");
    expect(fs.statSync(path.join(archiveDir, file)).mode & 0o777).toBe(0o600);
  });

  it("rolls back the retention transaction if archive persistence fails", () => {
    const live = repo.getOrCreateApplicant("archive-fails@example.ke", "t-archive-fails");
    const old = new Date(Date.now() - 1000 * 24 * 3600_000).toISOString();
    (repo as unknown as { db: { prepare: (q: string) => { run: (...x: unknown[]) => unknown } } }).db
      .prepare("UPDATE applicants SET lifecycle='completed', updated_at=? WHERE id=?").run(old, live.id);

    expect(() => repo.archiveAndDeleteDueApplicant(
      live.id,
      new Date().toISOString(),
      730,
      () => { throw new Error("simulated archive disk failure"); }
    )).toThrow("simulated archive disk failure");
    expect(repo.getApplicant(live.id)).toBeDefined();
  });

  it("refuses retention without the external key and leaves an eligible case untouched", () => {
    const dir = fs.mkdtempSync(path.join(os.tmpdir(), "retain-missing-key-"));
    const dbPath = path.join(dir, "t.sqlite");
    const db = openDb(dbPath);
    const r = new Repo(db);
    seedDefaults(r);
    configureTestOrganization(r);
    const old = new Date(Date.now() - 1000 * 24 * 3600_000).toISOString();
    const live = r.getOrCreateApplicant("needs-key@example.ke", "t-key");
    (r as unknown as { db: { prepare: (q: string) => { run: (...x: unknown[]) => unknown } } }).db
      .prepare("UPDATE applicants SET lifecycle='completed', demo=0, updated_at=? WHERE id=?").run(old, live.id);
    db.close();

    const run = spawnSync("./node_modules/.bin/tsx", ["src/cli/retain.ts"], {
      cwd: path.resolve(__dirname, ".."),
      env: { ...process.env, DB_PATH: dbPath, ARCHIVE_ENCRYPTION_KEY: "" },
      encoding: "utf8",
      timeout: 60_000,
    });
    expect(run.status).toBe(1);
    expect(run.stderr).toContain("ARCHIVE_ENCRYPTION_KEY is required");
    expect(fs.existsSync(path.join(dir, "archive"))).toBe(false);

    const checkDb = openDb(dbPath);
    expect(new Repo(checkDb).getApplicant(live.id)).toBeDefined();
    checkDb.close();
    fs.rmSync(dir, { recursive: true, force: true });
  });
});

describe("B4 — login throttle prunes by time, never blunt-clears", () => {
  it("blocks after 5 fails within a minute, recovers after the window, stays bounded", async () => {
    const { LoginThrottle } = await import("../src/web/throttle");
    const t = new LoginThrottle({ windowMs: 60_000, maxFails: 5, maxEntries: 1_000 });
    const now = Date.now();
    for (let i = 0; i < 4; i++) t.recordFail("1.2.3.4", now);
    expect(t.allowed("1.2.3.4", now)).toBe(true);
    t.recordFail("1.2.3.4", now);
    expect(t.allowed("1.2.3.4", now)).toBe(false);
    expect(t.allowed("1.2.3.4", now + 61_000)).toBe(true); // window rolls on

    // A flood of unique attackers must never grow the map without bound,
    // and must never bulk-wipe the memory (today: clear()): an IP that is
    // currently inside its block window stays blocked after the flood.
    for (let i = 0; i < 5_000; i++) t.recordFail(`10.0.${i & 255}.${i >> 8}`, now + 100);
    for (let i = 0; i < 5; i++) t.recordFail("9.9.9.9", now + 200);
    expect(t.size).toBeLessThanOrEqual(1_000);   // bounded memory
    expect(t.size).toBeGreaterThan(0);           // no bulk clear
    expect(t.allowed("9.9.9.9", now + 201)).toBe(false); // still blocked
  });
});

describe("B5 — the duplicate-send window is pruned, never blunt-cleared", () => {
  it("folds a repeat inside the window and forgets it once the window passes", async () => {
    const { SendGuard } = await import("../src/web/throttle");
    const guard = new SendGuard(5_000);
    const now = Date.now();
    expect(guard.allow("1:7:docs_request", now)).toBe(true);
    expect(guard.allow("1:7:docs_request", now + 40)).toBe(false); // double-click
    expect(guard.allow("2:7:docs_request", now + 41)).toBe(true); // another officer
    expect(guard.allow("1:8:docs_request", now + 42)).toBe(true); // another case
    expect(guard.allow("1:7:docs_request", now + 5_100)).toBe(true); // window rolled on
    expect(guard.size).toBe(1); // the three aged-out keys were pruned individually
  });

  it("keeps guarding in-flight sends while the volume crosses the old cap", async () => {
    const { SendGuard } = await import("../src/web/throttle");
    const guard = new SendGuard(5_000);
    const now = Date.now();
    expect(guard.allow("1:1:ack_received", now)).toBe(true);
    // The old implementation cleared everything past 2 000 entries, so this
    // flood erased the guard above and a re-click mailed the reply twice.
    for (let i = 0; i < 4_000; i++) guard.allow(`1:${i}:ack_received`, now + 10);
    expect(guard.allow("1:1:ack_received", now + 20)).toBe(false);
    expect(guard.size).toBeGreaterThan(0);
  });
});

describe("B6 — admin password reset uses the same rules as first-run setup", () => {
  it("rejects missing/mismatched confirm and short passwords; accepts a matched pair", async () => {
    const base = await boot([]);
    const { cookie, csrf } = await webLogin(base, "admin", "admin123");
    const target = repo.getStaffByUsername("admin")!;

    const reset = (password: string, confirm: string) =>
      fetch(`${base}/staff/password`, {
        method: "POST", redirect: "manual",
        headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
        body: `_csrf=${encodeURIComponent(csrf)}&id=${target.id}&password=${encodeURIComponent(password)}&confirm=${encodeURIComponent(confirm)}`,
      }).then((r) => decodeURIComponent(r.headers.get("location") ?? ""));

    expect(await reset("newpass123", "")).toContain("do not match");      // no confirm (today: saves!)
    expect(await reset("newpass123", "different456")).toContain("do not match");
    expect(await reset("short", "short")).toContain("at least 8");
    expect(await reset("newpass123", "newpass123")).toContain("Password reset for");
    // getStaff() intentionally omits the hash column — read it from the DB.
    const row = (repo as unknown as { db: { prepare: (q: string) => { get: (...x: unknown[]) => { password_hash: string } } } })
      .db.prepare("SELECT password_hash FROM staff_users WHERE id = ?").get(target.id);
    expect(verifyPassword("newpass123", row.password_hash)).toBe(true);
  });
});
