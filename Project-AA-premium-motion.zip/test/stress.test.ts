/**
 * Stress harness smoke test (OR gate). The full 1,000-case run is
 * `npm run stress`; here a reduced slice runs under vitest so the CI loop
 * catches regressions in the generic volume invariants: no crashes, no
 * automated decisions, draft-first replies, exact organization-owned slot
 * calculations, valid references and duplicate-message suppression.
 */
import { execFileSync } from "node:child_process";
import { existsSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";

describe("stress harness (OR gate)", () => {
  it("runs the sampled stress suite clean", () => {
    const tsxBin = resolve(__dirname, "../node_modules/.bin/tsx");
    if (!existsSync(tsxBin)) {
      throw new Error("tsx binary missing — run `npm install` before the stress gate");
    }
    const out = execFileSync(
      tsxBin,
      [resolve(__dirname, "../src/cli/stress.ts")],
      {
        env: { ...process.env, STRESS_N: "120", DISABLE_OCR: "1" },
        encoding: "utf8",
        timeout: 120_000,
      }
    );
    expect(out).toContain("RESULT:");
    expect(out).toMatch(/120\/120 cases clean — ALL GREEN/);
    expect(out).not.toContain("FAILED CASES");
    expect(out).not.toContain("DETERMINISM FAILURE");
  }, 150_000);
});
