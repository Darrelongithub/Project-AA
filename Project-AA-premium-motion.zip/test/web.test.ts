/**
 * Web console smoke tests — a real HTTP server (ephemeral port) against an
 * in-memory DB with a processed applicant. Covers auth, CSRF, dashboard,
 * case actions, and the public self-service status page.
 */
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { webLogin, configureTestOrganization, docLines, releaseAutomation } from "./helpers";
import { mustProcessed } from "./harness";
import type { Server } from "http";
import { openDb } from "../src/db/db";
import { Repo } from "../src/db/repo";
import { seedDefaults } from "../src/db/seed";
import { MockSender, MockVisionAdapter, type PipelineContext } from "../src/pipeline/adapters";
import { makeHeuristicWatcher } from "../src/watcher";
import { processEmail } from "../src/pipeline";
import { createApp } from "../src/web/server";
import {makeTextPdf } from "../src/simulation/pdfFactory";
import { hashPassword } from "../src/util/password";
import type { IncomingEmail } from "../src/types";

let server: Server;
let base = "";
let repo: Repo;
let ref = "";
let applicantEmail = "";
let sender: MockSender;
let ctx: PipelineContext;

beforeAll(async () => {
  repo = new Repo(openDb(":memory:"));
  seedDefaults(repo);
  // OR-1: seedDefaults no longer creates tenants or accounts — the test builds
  // its own configured organization first, then provisions its staff exactly
  // like the first-run setup screen would.
  configureTestOrganization(repo);
  repo.createStaff("admin", "System Administrator", hashPassword("admin123"), "admin");
  // Test fixtures: a real officer and manager (production-style, not demo).
  repo.createStaff("manager", "Mary Mwangi (User)", hashPassword("manager123"), "user");
  repo.createStaff("jane", "Jane Wairimu (User)", hashPassword("jane123"), "user");

  sender = new MockSender();
  ctx = {
    repo,
    adapters: { vision: new MockVisionAdapter(), watcher: makeHeuristicWatcher(), sender },
  };

  // One complete case (Green) and one queued (Orange) for the pages to show.
  const name = "WEB TEST CONTACT";
  const atts = await Promise.all(
    [
      // OR-5: the complete file follows THIS case type's own checklist.
      ["w-form.pdf", "request_form"],
      ["w-id.pdf", "id"],
    ].map(async ([fn, dt]) => ({
      filename: fn,
      mimeType: "application/pdf",
      content: await makeTextPdf(docLines(dt, { name })),
    }))
  );
  applicantEmail = "webtest@example.org";
  const email: IncomingEmail = {
    id: "web-e1", threadId: "web-t1", from: applicantEmail, fromName: "Web Test",
    subject: "Service request documents",
    body: "Please find my request form and identity document attached.\nConsent: yes",
    organizationId: 1, caseTypeCode: "SERVICE_REQUEST",
    receivedAt: new Date().toISOString(), attachments: atts,
  } as IncomingEmail;
  const res = mustProcessed(await processEmail(email, ctx));
  ref = res.refNumber!;

  const app = createApp({ repo, ctx });
  await new Promise<void>((resolve) => {
    server = app.listen(0, "127.0.0.1", () => resolve());
  });
  const addr = server.address();
  base = `http://127.0.0.1:${(addr as { port: number }).port}`;
});

afterAll(() => {
  server?.close();
});

async function login(): Promise<{ cookie: string; csrf: string }> {
  const r = await webLogin(base, "admin", "admin123");
  expect(r.status).toBe(302);
  return { cookie: r.cookie, csrf: r.csrf };
}

async function loginAs(username: string, password: string): Promise<{ cookie: string; csrf: string }> {
  const r = await webLogin(base, username, password);
  expect(r.status).toBe(302);
  return { cookie: r.cookie, csrf: r.csrf };
}

describe("web console", () => {
  it("redirects unauthenticated staff to /login", async () => {
    const res = await fetch(`${base}/`, { redirect: "manual" });
    expect(res.status).toBe(302);
    expect(res.headers.get("location")).toBe("/login");
  });

  it("redirects repeat setup visits to login instead of a confusing 404", async () => {
    const get = await fetch(`${base}/setup`, { redirect: "manual" });
    expect(get.status).toBe(302);
    expect(get.headers.get("location")).toContain("/login?msg=");

    const post = await fetch(`${base}/setup`, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: "",
      redirect: "manual",
    });
    expect(post.status).toBe(302);
    expect(post.headers.get("location")).toContain("/login?msg=");
  });

  it("rejects bad credentials", async () => {
    // Go through the real flow: fetch the page, get the login-CSRF pair,
    // then post wrong credentials WITH the token — the 401 must come from
    // the password check, not from a missing token.
    const r = await webLogin(base, "admin", "wrong");
    expect(r.status).toBe(401);
  });

  it("rejects a forged login POST without the login-CSRF token", async () => {
    const res = await fetch(`${base}/login`, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: "username=admin&password=admin123",
    });
    expect(res.status).toBe(403);
  });

  it("accepts independent one-time login tokens without relying on a CSRF cookie", async () => {
    const tokenFromPage = async () => {
      const page = await fetch(`${base}/login`);
      expect(page.headers.get("cache-control")).toContain("no-store");
      expect(page.headers.get("set-cookie") || "").not.toContain("lcsrf=");
      const html = await page.text();
      return (/name="_lcsrf" value="([^"]+)"/.exec(html) || [])[1] ?? "";
    };
    const firstToken = await tokenFromPage();
    const secondToken = await tokenFromPage();
    expect(firstToken).toBeTruthy();
    expect(secondToken).toBeTruthy();
    expect(firstToken).not.toBe(secondToken);

    const post = (token: string) => fetch(`${base}/login`, {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: `username=admin&password=admin123&_lcsrf=${encodeURIComponent(token)}`,
      redirect: "manual",
    });
    expect((await post(firstToken)).status).toBe(302);
    expect((await post(firstToken)).status).toBe(403); // one-time: replay is rejected
    expect((await post(secondToken)).status).toBe(302); // another tab remains valid
  });

  it("admin lands on the oversight dashboard (not applicant casework)", async () => {
    const { cookie } = await login();
    const res = await fetch(`${base}/`, { headers: { cookie } });
    const html = await res.text();
    expect(res.status).toBe(200);
    expect(html).toContain("Team practice");
    expect(html).toContain("Completed files and decisions");
    expect(html).toContain("System");
    // Round 18: ownership moved to Staff Configuration; activity feed removed.
    expect(html).not.toContain("Courses &amp; ownership");
    expect(html).not.toContain("Recent activity");
    expect(html).not.toContain("What needs my attention");
    expect(html).toContain("Staff Configuration");
    expect(html).toContain("Configuration");
  });

  it("officer lands on the casework dashboard", async () => {
    const r0 = await webLogin(base, "jane", "jane123");
    expect(r0.status).toBe(302);
    const cookie = r0.cookie;
    const html = await (await fetch(`${base}/`, { headers: { cookie } })).text();
    expect(html).toContain("Needs attention");
    expect(html).toContain("Emails today");
    expect(html).toContain("Automation accuracy");
    expect(html).toContain("Where applicants get stuck");
  });

  it("search finds the case by reference number", async () => {
    const { cookie } = await loginAs("jane", "jane123");
    const res = await fetch(`${base}/applicants?q=${encodeURIComponent(ref)}`, { headers: { cookie } });
    const html = await res.text();
    expect(html).toContain(ref);
    // full_name is read from the documents themselves (title-cased by the pipeline)
    expect(html).toContain("Web Test Contact");
  });

  it("case page shows checklist, documents, email history and audit trail", async () => {
    const { cookie } = await login();
    const a = repo.findByRef(ref)!;
    const res = await fetch(`${base}/case/${a.id}`, { headers: { cookie } });
    const html = await res.text();
    expect(html).toContain(ref);
    expect(html).toContain("✓");
    // OR-5: the complete file follows THIS case type's checklist — every
    // received document is shown on the case page.
    expect(html).toContain("Request form");
    expect(html).toContain("Identity document");
    expect(html).toContain("Email history");
    expect(html).toContain("Audit log");
    expect(html).toContain("Status history");
  });

  it("rejects POST actions without a CSRF token", async () => {
    const { cookie } = await login();
    const a = repo.findByRef(ref)!;
    const res = await fetch(`${base}/case/${a.id}/note`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: "body=hax",
    });
    expect(res.status).toBe(403);
  });

  it("staff can save an internal note (with CSRF)", async () => {
    const { cookie, csrf } = await login();
    const a = repo.findByRef(ref)!;
    const res = await fetch(`${base}/case/${a.id}/note`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&body=${encodeURIComponent("Applicant called. Waiting for original certificate.")}`,
      redirect: "manual",
    });
    expect(res.status).toBe(302);
    const notes = repo.notesForApplicant(a.id);
    expect(notes[0]?.body).toContain("Applicant called");
  });

  it("officer role cannot open settings", async () => {
    const { cookie } = await webLogin(base, "jane", "jane123");
    const settings = await fetch(`${base}/settings`, { headers: { cookie } });
    expect(settings.status).toBe(403);
  });

  it("public status lookup is retired — status now travels by email", async () => {
    const landing = await fetch(`${base}/status`, { redirect: "manual" });
    expect(landing.status).toBe(404);
    const portal = await fetch(`${base}/portal`, { redirect: "manual" });
    expect(portal.status).toBe(404);
  });

  it("v4 UI: splash, header shell, command palette and dark-mode toggle", async () => {
    const { cookie: sessionCookie, csrf } = await login();
    const cookie = `${sessionCookie}; theme=light`;
    const home = await (await fetch(`${base}/`, { headers: { cookie } })).text();
    expect(home).toContain('id="splash"');
    expect(home).toContain('class="sitehead sidebar"');
    expect(home).toContain('id="palette"');
    expect(home).toContain("Example Service Cooperative");
    expect(home).toContain("Your workspace"); // the default tagline
    expect(home).toContain('data-theme="light"');
    // The bundled type system uses Manrope for interface copy and Instrument Serif for display text.
    expect(home).toContain("/assets/fonts/manrope.woff2");
    expect(home).toContain('--display: var(--font-display)');
    expect(home).toContain("aᵃ");
    expect(home).toContain("Instrument Serif");
    const font = await fetch(`${base}/assets/fonts/manrope.woff2`);
    expect(font.status).toBe(200);
    expect(font.headers.get("content-type")).toBe("font/woff2");

    // Toggle to dark — cookie-driven, works on the next render.
    const tog = await fetch(`${base}/theme`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded", referer: `${base}/` },
      body: "",
      redirect: "manual",
    });
    expect(tog.status).toBe(302);
    const themeCookie = ((tog.headers.get("set-cookie") || "").match(/theme=[a-z]+/) || [])[0];
    expect(themeCookie).toBe("theme=dark");
    const darkHome = await (await fetch(`${base}/`, { headers: { cookie: `${cookie}; ${themeCookie}` } })).text();
    expect(darkHome).toContain('data-theme="dark"');
    expect(csrf).toBeTruthy();
  });

  it("v4 UI: command-palette search API returns applicants with avatars", async () => {
    const { cookie } = await loginAs("jane", "jane123");
    const res = await fetch(`${base}/api/search?q=webtest`, { headers: { cookie } });
    expect(res.status).toBe(200);
    const j = (await res.json()) as { applicants: Array<{ ref_number: string; avatar: string }> };
    expect(j.applicants.length).toBeGreaterThan(0);
    expect(j.applicants[0].ref_number).toBe(ref);
    expect(j.applicants[0].avatar).toContain("class=\"avatar\"");

    // Requires auth.
    const anon = await fetch(`${base}/api/search?q=x`, { redirect: "manual" });
    expect(anon.status).toBe(302);
  });

  it("separation is by dataset realm, and both roles reach the queues", async () => {
    // Admin: /queue is now an alias for the Human Review queue.
    const { cookie } = await login();
    const redir = await fetch(`${base}/queue`, { headers: { cookie }, redirect: "manual" });
    expect(redir.status).toBe(302);
    expect(redir.headers.get("location")).toContain("/applicants?queue=human_review");
    const page = await (await fetch(`${base}/applicants`, { headers: { cookie } })).text();
    expect(page).toContain("Queues");
    // Search is realm-scoped, never role-blocked: live admin finds live cases.
    const search = await fetch(`${base}/api/search?q=${encodeURIComponent(ref)}`, { headers: { cookie } });
    const j = (await search.json()) as { applicants: Array<{ ref_number: string }> };
    expect(j.applicants.length).toBe(1);
    expect(j.applicants[0].ref_number).toBe(ref);
    // Users reach the same queues.
    const { cookie: janeCookie } = await loginAs("jane", "jane123");
    const ok = await fetch(`${base}/applicants`, { headers: { cookie: janeCookie } });
    expect(ok.status).toBe(200);
  });
  it("exports applicants CSV (manager+)", async () => {
    const { cookie } = await login();
    const res = await fetch(`${base}/export/applicants.csv`, { headers: { cookie } });
    expect(res.status).toBe(200);
    expect(res.headers.get("content-type")).toContain("text/csv");
    const body = await res.text();
    expect(body).toContain("ref_number");
    expect(body).toContain(ref);
  });
});

describe("web console v3", () => {
  async function fullSetAtts(name: string) {
    return Promise.all(
      [
        // OR-5: a complete file per THIS case type's own checklist.
        ["v3-form.pdf", "request_form"],
        ["v3-id.pdf", "id"],
      ].map(async ([fn, dt]) => ({
        filename: fn,
        mimeType: "application/pdf",
        content: await makeTextPdf(docLines(dt, { name })),
      }))
    );
  }

  it("evaluation history page renders the frozen configuration and every run (feature 32)", async () => {
    const { cookie } = await login();
    const a = repo.findByRef(ref)!;
    const res = await fetch(`${base}/case/${a.id}/replay`, { headers: { cookie } });
    const html = await res.text();
    expect(res.status).toBe(200);
    expect(html).toContain("Evaluation history");
    expect(html).toContain("Frozen configuration");
    expect(html).toContain("Evaluation runs");
    // The run's own reasoning is quoted verbatim, so any verdict is explainable.
    expect(html).toContain("Requirement check");
    expect(html).toMatch(/Verdict: (Green|Orange|Red)/);
  });

  it("staff can add and toggle tasks on a case (feature 25)", async () => {
    const { cookie, csrf } = await login();
    const a = repo.findByRef(ref)!;
    const add = await fetch(`${base}/case/${a.id}/task/add`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&title=${encodeURIComponent("Verify the identity document with its issuer")}`,
      redirect: "manual",
    });
    expect(add.status).toBe(302);
    const page = await (await fetch(`${base}/case/${a.id}`, { headers: { cookie } })).text();
    expect(page).toContain("Verify the identity document with its issuer");
    const task = repo.listTasks(a.id)[0];
    const toggle = await fetch(`${base}/case/${a.id}/task/toggle`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&task_id=${task.id}`,
      redirect: "manual",
    });
    expect(toggle.status).toBe(302);
    expect(repo.listTasks(a.id).find((t) => t.id === task.id)?.done).toBe(1);
  });

  it("draft-first mode holds the reply and staff can approve it (features 16, 17)", async () => {
    const { cookie, csrf } = await login();
    repo.setAutomationMode("document_submission", "draft");
    const res = mustProcessed(await processEmail(
      {
        id: "web-held-1", threadId: "web-held-t", from: "held@example.org", fromName: "Held One",
        subject: "Service request documents", body: "Please find my papers attached.\nConsent: yes",
        organizationId: 1, caseTypeCode: "SERVICE_REQUEST",
        receivedAt: new Date().toISOString(), attachments: await fullSetAtts("HELD FOR APPROVAL"),
      } as IncomingEmail,
      ctx
    ));
    expect(res.finalStatus).toBe("Green");
    expect(res.autoSent).toBe(false);
    const a = repo.getApplicant(res.applicantId)!;
    expect(repo.queuedOutbox(a.id)).toBeTruthy();

    const page = await (await fetch(`${base}/case/${a.id}`, { headers: { cookie } })).text();
    expect(page).toContain("Draft held for approval");
    // Internal routing boilerplate must never be visible in the draft UI.
    expect(page).not.toContain("INTERNAL — DO NOT AUTO-SEND");

    const send = await fetch(`${base}/case/${a.id}/draft`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&decision=send&subject=${encodeURIComponent("[held] approval")}&body=${encodeURIComponent("Approved body")}`,
      redirect: "manual",
    });
    expect(send.status).toBe(302);
    expect(repo.queuedOutbox(a.id)).toBeUndefined();
    expect(repo.auditForApplicant(a.id).some((e) => e.event === "human_override")).toBe(true);
    repo.setAutomationMode("document_submission", "auto");
  });

  it("automation settings endpoints persist modes and intake deadlines (features 17, 20, 21)", async () => {
    const { cookie, csrf } = await login();
    const cat = await fetch(`${base}/settings/automation/category`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&category=complaint&mode=draft`,
      redirect: "manual",
    });
    expect(cat.status).toBe(302);
    expect(repo.allAutomationConfig().find((r) => r.category === "complaint")?.mode).toBe("draft");

    const dl = await fetch(`${base}/settings/intake-deadline`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&name=${encodeURIComponent("January 2027")}&deadline=2027-01-15`,
      redirect: "manual",
    });
    expect(dl.status).toBe(302);
    expect(repo.intakeDeadline("January 2027")).toContain("2027-01-15");
    // The window is visible AND editable — a deadline saved here is not a
    // write-only setting.
    const config = await (await fetch(`${base}/config?tab=requirements`, { headers: { cookie } })).text();
    expect(config).toContain("Submission windows");
    expect(config).toContain("January 2027");
    expect(config).toContain('value="2027-01-15"');
  });
});

describe("production-readiness pass", () => {
  it("applicants page shows the five operational queues with live counts", async () => {
    const { cookie } = await loginAs("jane", "jane123");
    const page = await (await fetch(`${base}/applicants`, { headers: { cookie } })).text();
    expect(page).toContain('class="queue-tabs"');
    for (const label of [
      "Completed / Verification",
      "Waiting for Documents",
      "Human Review Required",
      "Outcomes",
      "Enquiries &amp; Communication",
    ]) {
      expect(page).toContain(label);
    }
    // The Human Review queue is the default landing; subchips say "why".
    expect(page).toContain("/applicants?queue=human_review");
    expect(page).toMatch(/Evidence requires verification|Ready for review|Escalated/);
    const filtered = await (await fetch(`${base}/applicants?queue=waiting_documents`, { headers: { cookie } })).text();
    expect(filtered).toContain("Missing information");
  });

  it("case draft UI hides INTERNAL boilerplate and refuses to send it", async () => {
    const { cookie, csrf } = await login();
    const a = repo.findByRef(ref)!;
    repo.addOutbox({
      applicant_id: a.id, to_address: a.email_address,
      subject: "SUGGESTED REPLY (human review required)",
      body: "INTERNAL — DO NOT AUTO-SEND.\nThis case requires human review before any reply goes out. See flags and reasoning.",
      mode: "queued",
    });
    // The pipeline may hold its own draft on this case; track THIS row by id.
    const mine = (repo.db.prepare("SELECT id FROM outbox WHERE applicant_id = ? ORDER BY id DESC LIMIT 1").get(a.id) as { id: number }).id;
    const page = await (await fetch(`${base}/case/${a.id}`, { headers: { cookie } })).text();
    expect(page).toContain("Draft held for approval");
    expect(page).not.toContain("INTERNAL — DO NOT AUTO-SEND");

    // Sending the untouched internal draft is blocked.
    const blocked = await fetch(`${base}/case/${a.id}/draft`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&decision=send&subject=${encodeURIComponent("SUGGESTED REPLY")}&body=${encodeURIComponent("INTERNAL — DO NOT AUTO-SEND.\nThis case requires human review before any reply goes out.")}`,
      redirect: "manual",
    });
    expect(blocked.status).toBe(302);
    expect(decodeURIComponent(blocked.headers.get("location") || "")).toContain("internal routing notes");
    expect(repo.queuedOutbox(a.id)).toBeTruthy();

    // A cleaned body sends fine.
    const ok = await fetch(`${base}/case/${a.id}/draft`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&decision=send&subject=${encodeURIComponent("Your application")}&body=${encodeURIComponent("Thank you — we have received your documents.")}`,
      redirect: "manual",
    });
    expect(ok.status).toBe(302);
    expect(repo.db.prepare("SELECT id FROM outbox WHERE id = ?").get(mine)).toBeUndefined();
  });

  it("case page offers a Responses card with template preview", async () => {
    const { cookie, csrf } = await login();
    const a = repo.findByRef(ref)!;
    const page = await (await fetch(`${base}/case/${a.id}`, { headers: { cookie } })).text();
    expect(page).toContain("Responses");
    expect(page).toContain('name="template"');
    expect(page).toContain('name="preview"');

    const preview = await fetch(`${base}/case/${a.id}/send`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&template=missing_documents&preview=1`,
      redirect: "manual",
    });
    expect(preview.status).toBe(200);
    const html = await preview.text();
    expect(html).toContain("Preview only — nothing has been sent.");
    expect(html).toContain('class="resp-preview"');
  });

  it("managers can re-categorise the latest incoming email after review", async () => {
    const { cookie, csrf } = await login();
    const a = repo.findByRef(ref)!;
    const res = await fetch(`${base}/case/${a.id}/category`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&category=fee_enquiry`,
      redirect: "manual",
    });
    expect(res.status).toBe(302);
    const latestIn = repo.emailsForApplicant(a.id).filter((e) => e.direction === "in").pop();
    expect(latestIn?.category).toBe("fee_enquiry");
    expect(repo.auditForApplicant(a.id).some((e) => e.event === "category_changed")).toBe(true);
  });

  it("review queue never drops a case with a held draft or active flag, even after auto-send", async () => {
    const a = repo.findByRef(ref)!;
    const before = repo.queueView().some((q) => q.id === a.id);
    repo.addOutbox({ applicant_id: a.id, to_address: a.email_address, subject: "held", body: "x", mode: "queued" });
    expect(repo.queueView().some((q) => q.id === a.id)).toBe(true);
    repo.queuedOutbox(a.id) && repo.deleteOutbox(repo.queuedOutbox(a.id)!.id);
    repo.syncFlags(a.id, [{ type: "watcher_flag", detail: "sanity check for test" }]);
    expect(repo.queueView().some((q) => q.id === a.id)).toBe(true);
    repo.syncFlags(a.id, []); // clear derived flags
    expect(repo.queueView().some((q) => q.id === a.id)).toBe(before);
  });

  it("staff page merges team performance with account management", async () => {
    const { cookie } = await login();
    const stats = repo.staffStats();
    expect(stats.length).toBeGreaterThan(0);
    expect(stats.some((s) => s.username === "admin")).toBe(true);
    const page = await (await fetch(`${base}/staff`, { headers: { cookie } })).text();
    expect(page).toContain("Performance");
    expect(page).toContain("Avg response");
    expect(page).toContain("Accounts");
    const redirected = await fetch(`${base}/team`, { headers: { cookie }, redirect: "manual" });
    expect(redirected.status).toBe(302);
    expect(redirected.headers.get("location")).toBe("/staff");
  });

  it("flag names are human-readable on the case page", async () => {
    const { cookie } = await login();
    const a = repo.findByRef(ref)!;
    repo.syncFlags(a.id, [{ type: "name_mismatch", detail: "test rendering" }]);
    const page = await (await fetch(`${base}/case/${a.id}`, { headers: { cookie } })).text();
    expect(page).toContain("Name mismatch");
    expect(page).not.toContain(">name_mismatch<");
    repo.syncFlags(a.id, []);
  });

  it("workspace branding is configurable and defaults to the organization's own name", async () => {
    const { cookie } = await login();
    repo.setSetting("institution_name", "Test Cooperative");
    const home = await (await fetch(`${base}/`, { headers: { cookie } })).text();
    expect(home).toContain("Test Cooperative");
    const settings = await (await fetch(`${base}/settings`, { headers: { cookie } })).text();
    expect(settings).toContain("Letters &amp; identity");
    expect(settings).toContain('name="organization_name"');
    expect(settings).toContain('name="institution_name"');
    // The sign-in screen names the organization row, not a bundled brand.
    const loginHtml = await (await fetch(`${base}/login`)).text();
    expect(loginHtml).toContain("Example Service Cooperative");
    expect(loginHtml).not.toMatch(/riara/i);
    repo.setSetting("institution_name", "Example Service Cooperative");
  });

  it("settings page offers the Gmail connection card (moved out of Configuration)", async () => {
    const { cookie } = await login();
    // OR-4: ONE home for connections — Settings.
    const settings = await (await fetch(`${base}/settings`, { headers: { cookie } })).text();
    expect(settings).toContain("Gmail connection");
    expect(settings).toContain("not connected");
    expect(settings).toContain('action="/settings/gmail/credentials"');
    expect(settings).toContain("Automation mode");
    // Configuration no longer hosts connection controls.
    const cfg = await (await fetch(`${base}/config?tab=replies`, { headers: { cookie } })).text();
    expect(cfg).not.toContain('action="/settings/gmail/credentials"');
    expect(cfg).not.toContain("Gmail connection");
  });

  it("the legacy course catalogue is gone — assignment is rule data on a case type", async () => {
    const { cookie, csrf } = await login();
    // Round 3 kept course configuration on the staff page; the catalogue itself
    // is gone, and so is its owner-assignment form.
    const staff = await (await fetch(`${base}/staff`, { headers: { cookie } })).text();
    expect(staff).not.toContain("Courses &amp; ownership");
    expect(staff).not.toContain('action="/config/course-owner"');
    const gone = await fetch(`${base}/config/course-owner`, {
      method: "POST", headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&programme=BBIT&owner=1`, redirect: "manual",
    });
    expect(gone.status).toBe(404);
    // Who handles what is a workflow rule on a case type, editable in the rules tab…
    const rules = await (await fetch(`${base}/config?tab=rules`, { headers: { cookie } })).text();
    expect(rules).toContain("Workflow rules");
    const type = repo.getCaseType("SERVICE_REQUEST", 1)!;
    const member = repo.listStaff().find((m) => m.username === "jane")!;
    expect((await fetch(`${base}/config/workflow-rules/save`, {
      method: "POST", headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        _csrf: csrf, name: "Jane handles service requests", kind: "response",
        case_type_id: String(type.id), position: "8",
        cond_field_0: "always", cond_value_0: "true",
        reply_action: "draft", template_key: "status_answer",
        [`assign`]: String(member.id), audit_code: "rule_assigned_jane", fallback: "human_draft",
      }).toString(),
      redirect: "manual",
    })).status).toBe(302);
    const saved = repo.listWorkflowRules(1, { caseTypeId: type.id, kind: "response" }).find((r) => r.name === "Jane handles service requests")!;
    expect(saved.action.assign).toBe(member.id);
    // …and the person is visible on the team page.
    expect(staff).toContain("Jane Wairimu");
  });
});

describe("QA audit regressions", () => {
  it("unknown URLs get a branded 404, not a raw Express error", async () => {
    const { cookie } = await login();
    const res = await fetch(`${base}/no-such-page`, { headers: { cookie } });
    expect(res.status).toBe(404);
    const html = await res.text();
    expect(html).toContain("Page not found");
    expect(html).not.toContain("Cannot GET");
  });

  it("empty notes and tasks report honestly and persist nothing", async () => {
    const { cookie, csrf } = await login();
    const a = repo.findByRef(ref)!;
    const notesBefore = repo.notesForApplicant(a.id).length;
    const tasksBefore = repo.listTasks(a.id).length;
    const noteRes = await fetch(`${base}/case/${a.id}/note`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&body=`,
      redirect: "manual",
    });
    expect(decodeURIComponent(noteRes.headers.get("location") || "")).toContain("nothing saved");
    const taskRes = await fetch(`${base}/case/${a.id}/task/add`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&title=`,
      redirect: "manual",
    });
    expect(decodeURIComponent(taskRes.headers.get("location") || "")).toContain("nothing added");
    expect(repo.notesForApplicant(a.id).length).toBe(notesBefore);
    expect(repo.listTasks(a.id).length).toBe(tasksBefore);
  });

  it("a double-clicked template send goes out exactly once", async () => {
    const { cookie, csrf } = await login();
    const a = repo.findByRef(ref)!;
    const outBefore = repo.emailsForApplicant(a.id).filter((e) => e.direction === "out").length;
    const body = `_csrf=${csrf}&template=missing_documents`;
    const first = await fetch(`${base}/case/${a.id}/send`, {
      method: "POST", headers: { cookie, "content-type": "application/x-www-form-urlencoded" }, body, redirect: "manual",
    });
    expect(decodeURIComponent(first.headers.get("location") || "")).toContain("Sent");
    const second = await fetch(`${base}/case/${a.id}/send`, {
      method: "POST", headers: { cookie, "content-type": "application/x-www-form-urlencoded" }, body, redirect: "manual",
    });
    expect(decodeURIComponent(second.headers.get("location") || "")).toContain("Duplicate send ignored");
    const outAfter = repo.emailsForApplicant(a.id).filter((e) => e.direction === "out").length;
    expect(outAfter).toBe(outBefore + 1);
  });

  it("staff creation validates input instead of silently doing nothing", async () => {
    const { cookie, csrf } = await login();
    const post = (formBody: string) => fetch(`${base}/staff/add`, {
      method: "POST", headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&${formBody}`, redirect: "manual",
    });
    const short = await post("username=newperson&display_name=New&password=short&role=officer");
    expect(decodeURIComponent(short.headers.get("location") || "")).toContain("at least 8 characters");
    const dupe = await post("username=admin&display_name=Imposter&password=longenough1&role=officer");
    expect(decodeURIComponent(dupe.headers.get("location") || "")).toContain("already taken");
    expect(repo.getStaffByUsername("newperson")).toBeUndefined();
  });

  it("Gmail client secret is never echoed back into the settings page", async () => {
    const { cookie, csrf } = await login();
    const save = await fetch(`${base}/settings/gmail/credentials`, {
      method: "POST", headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}&gmail_address=x@y.z&gmail_client_id=cid&gmail_client_secret=TOP-SECRET-VALUE`,
      redirect: "manual",
    });
    expect(save.status).toBe(302);
    // OR-4: the Gmail card now lives in Settings — secret must not echo there,
    // and must not appear anywhere else either.
    const settingsPage = await (await fetch(`${base}/settings`, { headers: { cookie } })).text();
    expect(settingsPage).not.toContain("TOP-SECRET-VALUE");
    expect(settingsPage).toContain("saved — enter a new value to replace");
    const cfgPage = await (await fetch(`${base}/config?tab=replies`, { headers: { cookie } })).text();
    expect(cfgPage).not.toContain("TOP-SECRET-VALUE");
    // clean up
    repo.setSetting("gmail_address", ""); repo.setSetting("gmail_client_id", ""); repo.setSetting("gmail_client_secret", "");
  });

  it("an email containing only the case reference gets a factual status reply — drafted unless the tenant opted in", async () => {
    // A case type of its own, so this test controls the rule tree and the
    // reply rule: no rule constraints (nothing to satisfy from a bare
    // reference) and one always-true status rule.
    const type = repo.createCaseType(1, { code: "STATUS_ONLY", name: "status only", category: "general" });
    repo.saveWorkflowRule({
      organizationId: 1, caseTypeId: type.id, kind: "intake", name: "Open a status case", position: 0,
      conditions: [{ field: "always", value: true }], action: { decision: "create", audit_code: "rule_status_open" },
    });
    const statusRule = repo.saveWorkflowRule({
      organizationId: 1, caseTypeId: type.id, kind: "response", name: "Factual status answer", position: 0,
      conditions: [{ field: "always", value: true }],
      action: { reply_action: "draft", template_key: "status_answer", audit_code: "rule_status_draft" },
    });
    const opened = mustProcessed(await processEmail({
      id: "status-case-1", threadId: "status-t", from: "status@example.org", fromName: "Status Contact",
      subject: "status only request", body: "Please open a status only case for me.",
      organizationId: 1, caseTypeCode: "STATUS_ONLY",
      receivedAt: new Date().toISOString(), attachments: [],
    } as IncomingEmail, ctx));
    const a = repo.getApplicant(opened.applicantId)!;
    const refOnly = (id: string): IncomingEmail => ({
      id, threadId: "status-only-t", from: "status@example.org", fromName: "Status Contact",
      subject: "status", body: a.ref_number, organizationId: 1, caseTypeCode: "STATUS_ONLY",
      receivedAt: new Date().toISOString(), attachments: [],
    } as IncomingEmail);

    const outBefore = repo.emailsForApplicant(a.id).filter((e) => e.direction === "out").length;
    const res = await processEmail(refOnly("ref-only-1"), ctx);
    // Draft-first is the default: the factual status answer is prepared, quotes
    // the reference, and waits for a person — nothing goes out by itself.
    expect(res.applicantId).toBe(a.id); // a bare reference still finds the case
    expect(res.autoKind).toBe("status_answer");
    expect(res.autoSent).toBe(false);
    expect(repo.emailsForApplicant(a.id).filter((e) => e.direction === "out").length).toBe(outBefore);
    expect(repo.queuedOutbox(a.id)!.subject).toContain(a.ref_number);

    // An explicit opt-in — global automation, this case type, and the rule
    // itself — makes the same reply send. The global settings are restored
    // afterwards so the rest of the suite keeps its draft-first tenant.
    releaseAutomation(repo);
    repo.updateCaseTypeProfile(type.id, { default_reply_action: "auto", evidence_gate: 0 });
    repo.saveWorkflowRule({
      id: statusRule.id, organizationId: 1, caseTypeId: type.id, kind: "response",
      name: statusRule.name, position: statusRule.position, conditions: statusRule.conditions,
      action: { ...statusRule.action, reply_action: "send" },
    });
    try {
      const sent = await processEmail(refOnly("ref-only-1b"), ctx);
      expect(sent.autoSent).toBe(true);
      expect(sent.autoKind).toBe("status_answer");
      const outs = repo.emailsForApplicant(a.id).filter((e) => e.direction === "out");
      expect(outs.length).toBe(outBefore + 1);
      // The reply quotes the case reference in its subject and states the
      // stage in plain language — factual, and traceable to this case.
      expect(outs[outs.length - 1].subject).toContain(a.ref_number);
      expect(outs[outs.length - 1].body).toContain("Current stage");
    } finally {
      repo.setSetting("automation_mode", "draft");
    }
  });

  it("a stranger quoting someone else's reference number gets NO automatic status", async () => {
    const res = await processEmail(
      {
        id: "ref-only-2", threadId: "ref-only-t2", from: "stranger@example.org", fromName: "Stranger",
        subject: "status please", body: ref, organizationId: 1, caseTypeCode: "SERVICE_REQUEST",
        receivedAt: new Date().toISOString(), attachments: [],
      } as IncomingEmail,
      ctx
    );
    expect(res.autoSent).toBe(false);
  });

  it("dashboard shows 'no data' instead of fake zeros and the demo banner is truthful", async () => {
    const { cookie } = await login();
    const home = await (await fetch(`${base}/`, { headers: { cookie } })).text();
    // A fresh (non-demo) database must NOT show the demo banner — the banner
    // is gated on the demo_dataset flag that only the demo seeder sets.
    expect(home).not.toContain("Demo workspace");
    // No misleading raw zero values.
    expect(home).not.toContain(">0 min<");
    expect(home).not.toContain(">0 hrs<");
  });

  it("admin Overview carries an alerts panel that can clear unread alerts", async () => {
    repo.notify("escalation", "Case RU-ALERT escalation for admins", null);
    const { cookie: sessionCookie, csrf } = await login();
    const cookie = `${sessionCookie}; theme=light`;
    const home = await (await fetch(`${base}/`, { headers: { cookie } })).text();
    expect(home).toContain('id="alerts"');
    expect(home).toContain("Case RU-ALERT escalation for admins");
    const res = await fetch(`${base}/notifications/read-all`, {
      method: "POST",
      headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
      body: `_csrf=${csrf}`,
      redirect: "manual",
    });
    expect(res.status).toBe(302);
    const after = await (await fetch(`${base}/`, { headers: { cookie } })).text();
    expect(after).toContain('id="alerts"');
    expect(after).not.toContain("new</span>");
  });

  // OR-1 replaced the demo-dataset banner/badges: the product no longer has
  // any mock-data concept, so these tests pin the NEW contract instead.
  it("never shows a demo banner — even if an old demo flag lingers in settings", async () => {
    const { cookie } = await login();
    repo.setSetting("demo_dataset", "1"); // residue an old install might carry
    const withFlag = await (await fetch(`${base}/`, { headers: { cookie } })).text();
    expect(withFlag).not.toContain("Demo dataset loaded");
    expect(withFlag.toLowerCase()).not.toContain("demobar");
    repo.setSetting("demo_dataset", "0");
  });

  it("staff page has no demo badges and no seeded default-password machinery", async () => {
    const { cookie } = await login();
    const html = await (await fetch(`${base}/staff`, { headers: { cookie } })).text();
    expect(html).not.toContain("Sample account from the demo dataset");
    expect(html).not.toContain("default password");
    expect(html).not.toContain("demo_admin");
    expect(html).not.toContain("demo_user");
  });

  describe("configuration split, account settings & realm separation", () => {
    it("configuration keeps its own tabs; the legacy course and intake cards are gone", async () => {
      const { cookie } = await login();
      const config = await (await fetch(`${base}/config`, { headers: { cookie } })).text();
      expect(config).toContain("Reply configuration");
      expect(config).toContain("Requirements &amp; repairs");
      expect(config).toContain("Document library");
      // The legacy course catalogue has no home anywhere in the console.
      expect(config).not.toContain("Course configuration");
      expect(config).not.toContain('id="courses"');
      expect(config).not.toContain("Add a course or intake");
      expect(config).not.toContain('id="gmail"');
      const staff = await (await fetch(`${base}/staff`, { headers: { cookie } })).text();
      expect(staff).not.toContain('id="courses"');
      expect(staff).not.toContain("Add a course or intake");
      // Visibility scope is the case type now, and it is edited here.
      expect(staff).toContain("Visibility scope");
      expect(staff).toContain('action="/staff/scopes"');
      // Submission windows live with the requirements they gate.
      const requirements = await (await fetch(`${base}/config?tab=requirements`, { headers: { cookie } })).text();
      expect(requirements).toContain('id="intakes"');
      expect(requirements).toContain("Submission windows");

      const replies = await (await fetch(`${base}/config?tab=replies`, { headers: { cookie } })).text();
      // OR-4: connection controls moved OUT of Configuration to Settings.
      expect(replies).not.toContain('id="gmail"');
      // OR-7: templates moved OUT of Configuration into their own section.
      expect(replies).not.toContain('id="templates"');
      const templates = await (await fetch(`${base}/templates`, { headers: { cookie } })).text();
      expect(templates).toContain("All outgoing types");
      expect(templates).toContain('action="/templates/save"');
      const settings = await (await fetch(`${base}/settings`, { headers: { cookie } })).text();
      expect(settings).toContain('id="connections"');
      expect(settings).toContain('id="gmail"');
      expect(settings).toContain('id="gemini"');
      expect(replies).not.toContain('id="courses"');
      expect(config).not.toContain('id="courses"');
    });

    it("settings keeps SLA response targets visible and unrelated retention wording out", async () => {
      // RECONCILED (PPR P1-6): an older QA round removed response targets
      // ("automation is instant"); the production round requires SLA target
      // hours, escalation hours and the follow-up ladder back in real
      // Settings UI. The retention ban stands — P1-6 never asked for it.
      const { cookie } = await login();
      const settings = await (await fetch(`${base}/settings`, { headers: { cookie } })).text();
      expect(settings).toContain("Response targets");
      expect(settings).toContain("sla_target_hours");
      expect(settings).toContain("followup_ladder_days");
      expect(settings).not.toContain("Retention of completed cases");
      expect(settings).toContain("Letters &amp; identity");
    });

    it("every signed-in user gets self-service account settings (username, password, theme)", async () => {
      const { cookie } = await login();
      const page = await (await fetch(`${base}/account`, { headers: { cookie } })).text();
      expect(page).toContain('action="/account/username"');
      expect(page).toContain('action="/account/password"');
      expect(page).toContain('action="/account/theme"');
      expect(page).toContain("dark");
      expect(page).toContain("light");
    });

    it("a password change requires the current password and updates the login", async () => {
      const { cookie, csrf } = await login();
      // wrong current password → rejected
      const bad = await fetch(`${base}/account/password`, {
        method: "POST", headers: { cookie, "content-type": "application/x-www-form-urlencoded" },
        body: `_csrf=${csrf}&current=wrongpass&next=newpassword1&confirm=newpassword1`, redirect: "manual",
      });
      expect(bad.status).toBe(302);
      expect(decodeURIComponent(bad.headers.get("location") || "")).toContain("current password was incorrect");
    });

    it("cases are realm-guarded: an account never opens the other realm's files", async () => {
      // The processed applicant is live data (demo=0).
      const live = repo.searchApplicants({ demo: 0 });
      expect(live.length).toBeGreaterThan(0);
      // Mark the whole realm as demo, then a live-scoped search sees nothing.
      repo.db.prepare("UPDATE applicants SET demo = 1").run();
      expect(repo.searchApplicants({ demo: 0 }).length).toBe(0);
      expect(repo.searchApplicants({ demo: 1 }).length).toBeGreaterThan(0);
      // restore for other tests
      (repo as any).db.exec("UPDATE applicants SET demo = 0");
    });
  });

});
