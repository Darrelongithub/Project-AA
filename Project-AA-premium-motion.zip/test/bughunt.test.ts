/**
 * Regression tests for the bug-hunt fixes. One describe block per defect —
 * each test FAILS against the pre-fix code.
 */
import { describe, expect, it } from "vitest";
import { hashPassword } from "../src/util/password";
import { configureTestOrganization } from "./helpers";
import { openDb } from "../src/db/db";
import { Repo } from "../src/db/repo";
import { seedDefaults } from "../src/db/seed";
import { extractPhone } from "../src/enrich";
import { resolveIdentity } from "../src/matching/identity";
import { parseCookies } from "../src/web/auth";
import { sanitizeHeaders } from "../src/ingestion/gmailClient";
import { runFollowUpSweep } from "../src/followups";
import { MockSender, MockVisionAdapter } from "../src/pipeline/adapters";
import { makeHeuristicWatcher } from "../src/watcher";
import type { IncomingEmail } from "../src/types";

function freshRepo(): Repo {
  const repo = new Repo(openDb(":memory:"));
  seedDefaults(repo);
  configureTestOrganization(repo);
  return repo;
}


describe("bug: configuration writes duplicated rows (NULLs in UNIQUE)", () => {
  it("re-saving a document checklist keeps exactly one row per slot", () => {
    const repo = freshRepo();
    const type = repo.getCaseType("SERVICE_REQUEST", 1)!;
    const definitions = [
      { key: "request_form", label: "Request form", required: true, blocking: true },
      { key: "id", label: "Identity document", required: true, blocking: true },
    ];
    repo.replaceDocumentDefinitions(type.id, definitions);
    repo.replaceDocumentDefinitions(type.id, definitions);
    repo.upsertDocumentDefinition(type.id, { key: "id", label: "Photo ID", required: false, blocking: true });
    const rows = repo.listDocumentDefinitions(type.id);
    expect(rows.map((row) => row.key)).toEqual(["request_form", "id"]);
    expect(rows.find((row) => row.key === "id")).toMatchObject({ label: "Photo ID", required: false });
  });

  it("saving the same workflow rule twice updates it instead of duplicating", () => {
    const repo = freshRepo();
    const type = repo.getCaseType("VENDOR_INTAKE", 1)!;
    const input = {
      organizationId: 1, caseTypeId: type.id, kind: "response" as const, name: "Draft a vendor acknowledgement", position: 0,
      conditions: [{ field: "always" as const, value: true as const }],
      action: { reply_action: "draft" as const, template_key: "ack_received" },
    };
    const first = repo.saveWorkflowRule(input);
    const second = repo.saveWorkflowRule({ ...input, action: { reply_action: "draft", template_key: "status_answer" } });
    expect(second.id).toBe(first.id);
    expect(second.action.template_key).toBe("status_answer");
    expect(repo.listWorkflowRules(1, { caseTypeId: type.id, kind: "response" }).filter((rule) => rule.name === input.name)).toHaveLength(1);
  });

  it("the same rule name in another scope stays a separate rule", () => {
    const repo = freshRepo();
    const service = repo.getCaseType("SERVICE_REQUEST", 1)!;
    const vendor = repo.getCaseType("VENDOR_INTAKE", 1)!;
    const shared = { name: "Draft an acknowledgement", position: 0, conditions: [{ field: "always" as const, value: true as const }], action: { reply_action: "draft" as const } };
    const a = repo.saveWorkflowRule({ organizationId: 1, caseTypeId: service.id, kind: "response", ...shared });
    const b = repo.saveWorkflowRule({ organizationId: 1, caseTypeId: vendor.id, kind: "response", ...shared });
    expect(a.id).not.toBe(b.id);
    // An organization-wide rule with that name is a third, distinct scope.
    const c = repo.saveWorkflowRule({ organizationId: 1, caseTypeId: null, kind: "response", ...shared });
    expect([a.id, b.id, c.id]).toEqual([...new Set([a.id, b.id, c.id])]);
  });
});

describe("bug: getOrCreateApplicant race (check-then-insert)", () => {
  it("is idempotent and never throws on repeated creation", () => {
    const repo = freshRepo();
    const a = repo.getOrCreateApplicant("x@example.org", "t1");
    const b = repo.getOrCreateApplicant("x@example.org", "t1");
    expect(a.id).toBe(b.id);
    const n = (repo.db.prepare("SELECT COUNT(*) AS n FROM applicants").get() as { n: number }).n;
    expect(n).toBe(1);
  });
});

describe("bug: updateApplicant interpolated arbitrary column names into SQL", () => {
  it("refuses unknown columns instead of injecting them", () => {
    const repo = freshRepo();
    const a = repo.getOrCreateApplicant("y@example.org", "t1");
    expect(() =>
      (repo as any).updateApplicant(a.id, { "lifecycle = 'completed' WHERE 1; --": "x" })
    ).toThrow(/refusing unknown column/);
  });
});

describe("bug: todayStats used UTC date('now')", () => {
  it("counts a just-now email and excludes one from 25h ago", () => {
    const repo = freshRepo();
    const a = repo.getOrCreateApplicant("z@example.org", "t1");
    const now = new Date();
    repo.insertEmail({
      applicant_id: a.id, message_id: "m1", thread_id: "t1", direction: "in",
      from_addr: "z@example.org", to_addr: "", subject: "s", body: "b",
      category: null, auto: 0, at: now.toISOString(),
    });
    repo.insertEmail({
      applicant_id: a.id, message_id: "m2", thread_id: "t1", direction: "in",
      from_addr: "z@example.org", to_addr: "", subject: "s", body: "b",
      category: null, auto: 0, at: new Date(now.getTime() - 25 * 3600_000).toISOString(),
    });
    expect(repo.todayStats().emailsToday).toBe(1);
  });
});

describe("bug: searchApplicants did not escape LIKE wildcards", () => {
  it("a literal '%' query does not match the whole table", () => {
    const repo = freshRepo();
    repo.getOrCreateApplicant("p1@example.org", "t1", { fullName: "Alice One" });
    repo.getOrCreateApplicant("p2@example.org", "t2", { fullName: "Bob Two" });
    expect(repo.searchApplicants({ q: "%" }).length).toBe(0);
    expect(repo.searchApplicants({ q: "Alice" }).length).toBe(1);
  });
});

describe("bug: extractPhone matched inside longer digit runs", () => {
  it("rejects a phone-shaped substring of a longer number", () => {
    // 15-digit run containing what looks like 0712345678 inside.
    expect(extractPhone("ID 9990712345678999")).toBeNull();
  });
  it("accepts a properly delimited number", () => {
    expect(extractPhone("call me on 0712 345 678 thanks")).toBe("+254712345678");
    expect(extractPhone("tel: +254712345678.")).toBe("+254712345678");
  });
});

describe("bug: portal filename could inject another applicant's ref", () => {
  it("synthetic (non-email) channels never use quoted refs for identity", () => {
    const repo = freshRepo();
    const victim = repo.getOrCreateApplicant("victim@example.org", "tv");
    const email: IncomingEmail = {
      id: "pu-1",
      threadId: "t-attacker",
      from: "attacker@example.org",
      subject: `Portal upload: ${victim.ref_number}.pdf`,
      body: "",
      receivedAt: new Date().toISOString(),
      attachments: [],
      channel: "portal",
    };
    const res = resolveIdentity(repo, email);
    expect(res.applicant.id).not.toBe(victim.id);
    expect(res.applicant.email_address).toBe("attacker@example.org");
  });

  it("real emails still resolve via quoted refs", () => {
    const repo = freshRepo();
    const victim = repo.getOrCreateApplicant("victim@example.org", "tv");
    const email: IncomingEmail = {
      id: "em-1",
      threadId: "t-new",
      from: "victim@example.org",
      subject: `Re: your application ${victim.ref_number}`,
      body: "",
      receivedAt: new Date().toISOString(),
      attachments: [],
    };
    const res = resolveIdentity(repo, email);
    expect(res.applicant.id).toBe(victim.id);
    expect(res.matchedBy).toBe("ref");
    expect(res.concern).toBeUndefined();
  });
});

describe("bug: parseCookies threw URIError on malformed cookies", () => {
  it("returns the raw value instead of throwing", () => {
    expect(() => parseCookies("sid=%zz; theme=dark")).not.toThrow();
    expect(parseCookies("theme=dark").theme).toBe("dark");
  });
});

describe("bug: outgoing MIME headers were injectable", () => {
  it("strips CRLF from subject/to and RFC2047-encodes non-ASCII subjects", () => {
    const h = sanitizeHeaders("a@b.org", "Hello\r\nBcc: evil@x.org");
    expect(h.subject).not.toMatch(/[\r\n]/);
    // The injected header survives only as literal TEXT inside the Subject
    // value — single-line, so MIME parsers treat it as subject content.
    expect(h.subject).toBe("Hello Bcc: evil@x.org");
    const utf = sanitizeHeaders("a@b.org", "Karibu — your file");
    expect(utf.subject.startsWith("=?UTF-8?B?")).toBe(true);
  });
});

describe("bug: follow-up ladder stacked intervals instead of absolute days", () => {
  it("schedules the next rung relative to the ladder base date", async () => {
    const repo = freshRepo();
    const sender = new MockSender();
    const ctx = {
      repo,
      adapters: { vision: new MockVisionAdapter(), watcher: makeHeuristicWatcher(), sender },
    };
    // The ladder chases a configured checklist: an unconfigured case has
    // nothing outstanding, so it is never reminded.
    const a = repo.createCase({ emailAddress: "ladder@example.test", threadId: "t1", organizationId: 1, caseTypeCode: "SERVICE_REQUEST" });
    // Armed 8 days ago with ladder 3,7,10 → rung 1 fired at day 3 (past due),
    // and the NEXT rung must be base+7d (≈ 1 day ago), NOT now+7d.
    const base = new Date(Date.now() - 8 * 24 * 3600_000);
    repo.setFollowup(a.id, 0, new Date(Date.now() - 5 * 24 * 3600_000).toISOString(), base.toISOString());
    const sent = await runFollowUpSweep(repo, ctx);
    expect(sent).toBe(1);
    // Evidence gate: the rung is HELD as a staff suggestion, never sent.
    expect(sender.sent.length).toBe(0);
    expect(repo.queuedOutbox(a.id)?.subject).toContain("REMINDER");
    const row = repo.getApplicant(a.id)!;
    expect(row.followup_rung).toBe(1);
    const expected = base.getTime() + 7 * 24 * 3600_000;
    const actual = new Date(row.followup_next_at!).getTime();
    expect(Math.abs(actual - expected)).toBeLessThan(60_000);
  });
});

describe("bug: unreadable attachments were logged as gemini_vision", () => {
  it("total extraction failure records method 'none'", async () => {
    const { extractAttachment } = await import("../src/extraction/extract");
    const res = await extractAttachment(
      { filename: "x.bin", mimeType: "application/octet-stream", content: Buffer.from([1, 2, 3]) },
      { vision: new MockVisionAdapter() }
    );
    expect(res.method).toBe("none");
    expect(res.document_type).toBe("unknown");
    expect(res.confidence).toBe("low");
  });

  it("oversized attachments are rejected before any heavy tier", async () => {
    const { extractAttachment, MAX_ATTACHMENT_BYTES } = await import("../src/extraction/extract");
    const res = await extractAttachment(
      { filename: "big.pdf", mimeType: "application/pdf", content: Buffer.alloc(MAX_ATTACHMENT_BYTES + 1) },
      { vision: new MockVisionAdapter() }
    );
    expect(res.method).toBe("none");
    expect(res.document_type).toBe("unknown");
  });
});

describe("bug: /theme was an open redirect via the Referer header", () => {
  it("only redirects to same-origin relative paths", async () => {
    const { createApp } = await import("../src/web/server");
    const repo = freshRepo();
    const sender = new MockSender();
    const ctx = {
      repo,
      adapters: { vision: new MockVisionAdapter(), watcher: makeHeuristicWatcher(), sender },
    };
    const app = createApp({ repo, ctx });
    const server = app.listen(0);
    const port = (server.address() as { port: number }).port;
    const base = `http://127.0.0.1:${port}`;
    try {
      // Hostile referer → stay on "/".
      const evil = await fetch(`${base}/theme`, {
        method: "POST",
        redirect: "manual",
        headers: { referer: "https://evil.example.com/phish" },
      });
      expect(evil.headers.get("location")).toBe("/");
      // Same-origin referer → back to that path.
      const good = await fetch(`${base}/theme`, {
        method: "POST",
        redirect: "manual",
        headers: { referer: `${base}/queue` },
      });
      expect(good.headers.get("location")).toBe("/queue");
      // Protocol-relative trap ("//evil.com") must not pass as a path.
      const tricky = await fetch(`${base}/theme`, {
        method: "POST",
        redirect: "manual",
        headers: { referer: `${base}//evil.example.com` },
      });
      expect(tricky.headers.get("location")).toBe("/");
    } finally {
      server.close();
    }
  });
});

describe("bug: sessions were never purged after boot", () => {
  it("creating a session purges expired rows", () => {
    const repo = freshRepo();
    // OR-1: no accounts are seeded — create one for the session to belong to.
    repo.createStaff("admin", "System Administrator", hashPassword("admin123"), "admin");
    const staff = repo.getStaffByUsername("admin")!;
    repo.db
      .prepare("INSERT INTO sessions (token, staff_id, csrf, expires_at) VALUES (?,?,?,?)")
      .run("dead-token", staff.id, "c", new Date(Date.now() - 1000).toISOString());
    repo.createSession(staff.id);
    expect(repo.db.prepare("SELECT COUNT(*) AS n FROM sessions WHERE token = 'dead-token'").get()).toMatchObject({ n: 0 });
  });
});
